
<h3>Clientes </h3>
    <a href="{{route('cliente.create')}}"> Novo Cliente</a>
    <ol>
    @foreach ($clientes as $cliente)
    <li>
        {{ $cliente['nome'] }}
        <a href="{{route('cliente.edit',$cliente['id'])}}"> Editar</a>
    </li>
    @endforeach
</ol>